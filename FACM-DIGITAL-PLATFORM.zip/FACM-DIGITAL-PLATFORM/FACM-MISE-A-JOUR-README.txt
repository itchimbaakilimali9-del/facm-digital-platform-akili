FACM DIGITAL PLATFORM — MISE À JOUR ANALYTICS, PUSH ET GESTION UTILISATEURS

CONTENU
- supabase/functions/manage-users/index.ts : remplacement complet de la fonction de gestion des comptes.
- supabase/functions/site-analytics/index.ts : collecte des visites et lecture des statistiques.
- supabase/functions/send-push/index.ts : notifications Push pour candidatures et nouveaux visiteurs.
- supabase/migrations/20261124_facm_analytics_push.sql : tables et politiques.
- assets/js/facm-tracking.js : suivi des visiteurs (site public + portail candidat).
- assets/js/facm-push.js : activation des notifications sur l'appareil administrateur.
- sw.js : Service Worker avec réception et ouverture des notifications.
- index.html, candidates/index.html, admin/dashboard.html : scripts et cartes statistiques intégrés.

ÉTAPE 1 — SAUVEGARDE
Faites une copie complète du projet et de la base avant toute opération.

ÉTAPE 2 — SQL
Dans Supabase > SQL Editor, exécutez le contenu de :
supabase/migrations/20261124_facm_analytics_push.sql

ÉTAPE 3 — SECRETS ET DÉPLOIEMENT DES EDGE FUNCTIONS
Les trois dossiers de fonctions doivent être déployés dans le même projet Supabase que l'application.
Les variables SUPABASE_URL, SUPABASE_ANON_KEY et SUPABASE_SERVICE_ROLE_KEY doivent être configurées côté Edge Functions. SUPABASE_SERVICE_ROLE_KEY ne doit JAMAIS être publiée dans le navigateur.

Avec Supabase CLI (depuis la racine du projet) :
  supabase functions deploy manage-users
  supabase functions deploy site-analytics
  supabase functions deploy send-push

Si les variables système ne sont pas injectées automatiquement par votre environnement, définissez les secrets côté Supabase/CLI :
  supabase secrets set SUPABASE_URL=https://VOTRE-PROJET.supabase.co
  supabase secrets set SUPABASE_ANON_KEY=VOTRE_CLE_PUBLISHABLE_OU_ANON
  supabase secrets set SUPABASE_SERVICE_ROLE_KEY=VOTRE_SERVICE_ROLE_KEY

Ne collez jamais la service_role dans un fichier HTML, JS ou dans un message public.

ÉTAPE 4 — CLÉS VAPID POUR WEB PUSH
Sur un ordinateur avec Node.js, exécutez :
  npx web-push generate-vapid-keys
Conservez les deux clés. Configurez côté Supabase :
  supabase secrets set VAPID_PUBLIC_KEY=VOTRE_CLE_PUBLIQUE
  supabase secrets set VAPID_PRIVATE_KEY=VOTRE_CLE_PRIVEE
  supabase secrets set VAPID_SUBJECT=mailto:itchimbaakilimali9@gmail.com
  supabase secrets set FACM_WEBHOOK_SECRET=UNE_LONGUE_CLE_ALEATOIRE

Puis ouvrez assets/js/facm-push.js et remplacez la valeur REMPlACER_PAR_VOTRE_CLE_VAPID_PUBLIQUE par la clé publique VAPID exacte.
Redéployez send-push après configuration des secrets.

ÉTAPE 5 — WEBHOOKS DE BASE DE DONNÉES
Dans Supabase > Database > Webhooks, créez deux webhooks HTTP POST vers :
  https://VOTRE-PROJET.supabase.co/functions/v1/send-push
Webhook A : table public.applications, événement INSERT.
Webhook B : table public.site_page_views, événement INSERT.
Ajoutez l'en-tête HTTP :
  x-facm-webhook-secret: LA_MEME_VALEUR_QUE_FACM_WEBHOOK_SECRET
Le webhook doit transmettre le corps JSON standard contenant les champs type, table et record.

ÉTAPE 6 — DÉPLOIEMENT DU SITE
Publiez l'ensemble du dossier mis à jour sur Netlify en conservant la structure des dossiers.
Le site doit être servi en HTTPS.

ÉTAPE 7 — ACTIVER LES ALERTES SUR ANDROID
1. Ouvrez le site dans Chrome Android.
2. Installez/ajoutez FACM à l'écran d'accueil (PWA).
3. Connectez-vous au tableau de bord avec le compte administrateur.
4. Ouvrez Notifications puis cliquez « Activer les alertes sur ce téléphone ».
5. Autorisez les notifications dans Chrome et dans Android.
6. Refaites cette opération sur chaque téléphone/appareil qui doit recevoir les alertes.

LIMITES IMPORTANTES
- Les Push peuvent arriver lorsque l'écran est éteint si Android, Chrome et le système autorisent l'activité en arrière-plan. Le mode économie d'énergie, les restrictions de batterie, le réseau et les réglages de notification peuvent retarder ou bloquer une alerte. Aucun site web ne peut garantir une livraison instantanée dans toutes les situations.
- Sur iPhone, les Web Push nécessitent iOS/iPadOS 16.4 ou ultérieur et l'application web ajoutée à l'écran d'accueil.
- Les visiteurs « en ligne » sont les sessions ayant envoyé un signal dans les 90 dernières secondes. C'est une estimation technique, pas un comptage biométrique/personnel.
- Les statistiques commencent à compter après le déploiement. Elles ne reconstituent pas les visites historiques.
- La notification de visite est envoyée une seule fois par session navigateur, pas à chaque page consultée, pour limiter le spam.
- La suppression de compte efface les candidatures et les pièces jointes liées à ce compte. Vérifiez vos obligations de conservation avant usage en production.

DIAGNOSTIC COMPTES
La nouvelle fonction protège le compte principal itchimbaakilimali9@gmail.com. La consultation de la liste est permise à tout administrateur actif ; les mutations (création, modification, activation/désactivation et suppression) sont réservées au compte principal. Les comptes créés par l'interface sont confirmés côté Auth afin d'éviter un blocage de connexion par e-mail non confirmé.

À TESTER AVANT PRODUCTION
- créer un administrateur secondaire puis se connecter avec son adresse/mot de passe;
- vérifier qu'il voit le tableau de bord mais ne peut pas gérer les comptes;
- tester activation/désactivation;
- supprimer un compte test qui possède une candidature et des pièces jointes;
- tester les visites depuis deux appareils et vérifier le compteur en ligne;
- envoyer une candidature test et vérifier notification Push écran verrouillé.
