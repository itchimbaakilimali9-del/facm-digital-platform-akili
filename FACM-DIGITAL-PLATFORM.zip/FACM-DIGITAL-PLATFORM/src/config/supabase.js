
/* =========================================
   FACM DIGITAL PLATFORM
   Configuration Supabase
========================================= */

const FACM_SUPABASE_URL = "https://unvgqxwsuabxmpntytze.supabase.co";

const FACM_SUPABASE_KEY = "sb_publishable_LL1PPfo1Dg9Dy5Fv8Lb9lQ_Zlm6er9A";

if (!window.supabase) {
  throw new Error("La bibliothèque Supabase n'est pas chargée.");
}

window.facmSupabase = window.supabase.createClient(
  FACM_SUPABASE_URL,
  FACM_SUPABASE_KEY
);

console.log("FACM : client Supabase initialisé.");
