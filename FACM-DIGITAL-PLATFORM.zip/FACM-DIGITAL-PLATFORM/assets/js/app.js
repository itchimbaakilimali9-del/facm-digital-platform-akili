
/* =====================================================
   FACM DIGITAL PLATFORM
   APPLICATION JAVASCRIPT
   VERSION CONSOLIDÉE
   ===================================================== */


/* =====================================================
   OUTILS GÉNÉRAUX
   ===================================================== */

function facmLog(message) {
  console.log("[FACM]", message);
}

function elementExists(id) {
  return document.getElementById(id) !== null;
}

function facmEscapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

function facmSafeURL(value) {
  if (!value) return "";

  try {
    const url = new URL(value);

    if (url.protocol === "https:" || url.protocol === "http:") {
      return url.href;
    }
  } catch (error) {
    return "";
  }

  return "";
}

function facmFormatDate(value) {
  if (!value) return "";

  const date = new Date(value + "T00:00:00");

  if (Number.isNaN(date.getTime())) return "";

  return date.toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });
}


/* =====================================================
   INITIALISATION GÉNÉRALE
   ===================================================== */

document.addEventListener("DOMContentLoaded", () => {

  console.log("FACM DIGITAL PLATFORM : application initialisée.");

  
const initializers = [
    initializePublicLogo,
    initializeMobileMenu,
    initializeCurrentYear,
    initializeNavigation,
    initializeHeader,
    initializePublicActivities,
    initializePublicNews,
    initializePublicEditions,
    initializePublicTeam,
    initializePublicPartners,
    initializePublicMedia
  ];

  initializers.forEach(initializer => {
    try {
      initializer();
    } catch (error) {
      console.error(
        "Erreur d'initialisation FACM : " + initializer.name,
        error
      );
    }
  });

});


/* =====================================================
   MENU MOBILE
   ===================================================== */

function initializeMobileMenu() {

  const menuButton = document.getElementById("menu-toggle");
  const navigation = document.getElementById("navigation");

  if (!menuButton || !navigation) return;

  if (menuButton.dataset.facmInitialized === "true") return;

  menuButton.dataset.facmInitialized = "true";

  menuButton.addEventListener("click", () => {

    const isOpen = navigation.classList.toggle("open");

    menuButton.setAttribute("aria-expanded", String(isOpen));

    menuButton.innerHTML = isOpen
      ? '<i class="fa-solid fa-xmark"></i>'
      : '<i class="fa-solid fa-bars"></i>';

  });

  navigation.querySelectorAll("a").forEach(link => {

    link.addEventListener("click", () => {

      navigation.classList.remove("open");
      menuButton.setAttribute("aria-expanded", "false");

      menuButton.innerHTML =
        '<i class="fa-solid fa-bars"></i>';

    });

  });

  document.addEventListener("click", event => {

    const clickedInside =
      navigation.contains(event.target) ||
      menuButton.contains(event.target);

    if (!clickedInside) {

      navigation.classList.remove("open");
      menuButton.setAttribute("aria-expanded", "false");

      menuButton.innerHTML =
        '<i class="fa-solid fa-bars"></i>';

    }

  });

}


/* =====================================================
   ANNÉE AUTOMATIQUE
   ===================================================== */

function initializeCurrentYear() {

  const yearElement = document.getElementById("current-year");

  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }

}


/* =====================================================
   NAVIGATION
   ===================================================== */

function initializeNavigation() {

  const links = document.querySelectorAll(
    '.navigation a[href^="#"]'
  );

  links.forEach(link => {

    link.addEventListener("click", () => {

      links.forEach(item => {
        item.classList.remove("active");
      });

      link.classList.add("active");

    });

  });

}


/* =====================================================
   HEADER
   ===================================================== */

function initializeHeader() {

  const header = document.getElementById("header");

  if (!header) return;

  window.addEventListener("scroll", () => {

    header.style.boxShadow = window.scrollY > 50
      ? "0 5px 25px rgba(0,0,0,0.18)"
      : "none";

  }, { passive: true });

}


/* =====================================================
   LOGO OFFICIEL FACM — CHARGEMENT DEPUIS SUPABASE
   ===================================================== */


async function initializePublicLogo() {

  const db = window.facmSupabase;

  if (!db) {
    console.error("FACM : connexion Supabase indisponible pour le logo.");
    return;
  }

  try {

    const { data, error } = await db
      .from("platform_settings")
      .select("logo_url, updated_at")
      .eq("id", true)
      .maybeSingle();

    if (error) throw error;

    if (!data || !data.logo_url) {
      console.warn("FACM : aucun logo officiel enregistré.");
      return;
    }

    const logoURL = facmSafeURL(data.logo_url);

    if (!logoURL) {
      console.error("FACM : URL du logo invalide.");
      return;
    }

    const displayURL = new URL(logoURL);

    if (data.updated_at) {
      displayURL.searchParams.set(
        "v",
        String(new Date(data.updated_at).getTime())
      );
    }

    const finalLogoURL = displayURL.href;

    // LOGO DE L'EN-TÊTE ET DU PIED DE PAGE
    document.querySelectorAll(".brand-logo").forEach(logoElement => {

      const image = document.createElement("img");

      image.src = finalLogoURL;
      image.alt = "Logo officiel du Festival Afro Culturel Maniema";
      image.loading = "eager";
      image.decoding = "async";

      image.onerror = () => {
        console.error("FACM : erreur d'affichage du logo.");
        image.remove();
      };

      logoElement.replaceChildren(image);

    });

    // GRAND LOGO CENTRAL DU HERO
    const centralLogo = document.querySelector(".visual-logo");

    if (centralLogo) {

      centralLogo.src = finalLogoURL;
      centralLogo.alt = "Logo officiel du Festival Afro Culturel Maniema";
      centralLogo.loading = "eager";
      centralLogo.decoding = "async";

      centralLogo.onerror = () => {
        console.error("FACM : impossible d'afficher le logo central.");
      };

    }

    console.log("FACM : logos officiels chargés avec succès.");

  } catch (error) {

    console.error("Erreur chargement du logo FACM :", error);

  }

}


/* =====================================================
   ÉDITIONS PUBLIQUES
   ===================================================== */

async function initializePublicEditions() {

  const container = document.getElementById(
    "public-editions-container"
  );

  if (!container) return;

  const db = window.facmSupabase;

  if (!db) {
    container.textContent =
      "Le service des éditions est momentanément indisponible.";
    return;
  }

  try {

    const { data, error } = await db
      .from("editions")
      .select(`
        id,
        title,
        edition_number,
        year,
        description,
        start_date,
        end_date,
        location
      `)
      .eq("status", "published")
      .order("year", { ascending: false })
      .order("edition_number", { ascending: false });

    if (error) throw error;

    const editions = data || [];

    if (editions.length === 0) {

      container.innerHTML = `
        <div class="editions-empty">
          <div class="edition-icon">
            <i class="fa-solid fa-award"></i>
          </div>
          <h3>Nos éditions seront bientôt présentées</h3>
          <p>
            Retrouvez prochainement les différentes éditions
            du Festival Afro Culturel Maniema.
          </p>
        </div>
      `;

      return;
    }

    container.innerHTML = `
      <div class="public-editions-grid">

        ${editions.map(item => {

          const startDate = item.start_date
            ? new Date(item.start_date + "T00:00:00")
            : null;

          const validDate = startDate &&
            !Number.isNaN(startDate.getTime());

          const day = validDate
            ? startDate.getDate()
            : item.year || "FACM";

          const month = validDate
            ? startDate.toLocaleDateString("fr-FR", {
                month: "long"
              }).toUpperCase()
            : "ÉDITION";

          const year = item.year ||
            (validDate ? startDate.getFullYear() : "");

          const number = Number(item.edition_number);

          const editionLabel = number === 1
            ? "1ère ÉDITION"
            : number > 1
              ? number + "ème ÉDITION"
              : "ÉDITION DU FESTIVAL";

          let dateText = "";

          if (item.start_date && item.end_date) {
            dateText =
              facmFormatDate(item.start_date) +
              " au " +
              facmFormatDate(item.end_date);
          } else if (item.start_date) {
            dateText = facmFormatDate(item.start_date);
          }

          return `
            <article class="edition-card">

              <div class="edition-date">
                <span>${facmEscapeHTML(day)}</span>
                <strong>${facmEscapeHTML(month)}</strong>
                <small>${facmEscapeHTML(year)}</small>
              </div>

              <div class="edition-content">

                <span class="edition-status">
                  ${facmEscapeHTML(editionLabel)}
                </span>

                <h3>${facmEscapeHTML(
                  item.title || "Édition du Festival Afro Culturel Maniema"
                )}</h3>

                ${dateText ? `
                  <p class="edition-period">
                    <i class="fa-regular fa-calendar"></i>
                    ${facmEscapeHTML(dateText)}
                  </p>
                ` : ""}

                ${item.location ? `
                  <p class="edition-location">
                    <i class="fa-solid fa-location-dot"></i>
                    ${facmEscapeHTML(item.location)}
                  </p>
                ` : ""}

                ${item.description ? `
                  <p>${facmEscapeHTML(item.description)}</p>
                ` : ""}

              </div>

              <div class="edition-icon">
                <i class="fa-solid fa-award"></i>
              </div>

            </article>
          `;

        }).join("")}

      </div>
    `;

  } catch (error) {

    console.error("Erreur éditions publiques :", error);

    container.innerHTML = `
      <div class="editions-empty">
        <h3>Impossible de charger les éditions</h3>
        <p>Veuillez réessayer ultérieurement.</p>
      </div>
    `;

  }

}


/* =====================================================
   ACTIVITÉS PUBLIQUES
   ===================================================== */

async function initializePublicActivities() {

  const container = document.getElementById(
    "public-activities-container"
  );

  if (!container) return;

  const db = window.facmSupabase;

  if (!db) {
    container.textContent =
      "Le service des activités est momentanément indisponible.";
    return;
  }

  try {

    const { data, error } = await db
      .from("activities")
      .select(`
        id,
        title,
        activity_type,
        description,
        start_date,
        end_date,
        start_time,
        end_time,
        location,
        image_url
      `)
      .eq("status", "published")
      .order("start_date", { ascending: true });

    if (error) throw error;

    const activities = data || [];

    if (activities.length === 0) {

      container.innerHTML = `
        <div class="activities-empty">
          <i class="fa-regular fa-calendar"></i>
          <h3>Aucune activité publiée pour le moment</h3>
          <p>
            Retrouvez prochainement le programme officiel du festival.
          </p>
        </div>
      `;

      return;
    }

    container.innerHTML = `
      <div class="public-activities-grid">

        ${activities.map(activity => {

          const imageURL = facmSafeURL(activity.image_url);

          const imageHTML = imageURL ? `
            <div class="public-activity-image">
              <img
                src="${facmEscapeHTML(imageURL)}"
                alt="${facmEscapeHTML(activity.title)}"
                loading="lazy">
            </div>
          ` : "";

          const dateText =
            activity.end_date &&
            activity.end_date !== activity.start_date
              ? facmFormatDate(activity.start_date) +
                " au " + facmFormatDate(activity.end_date)
              : facmFormatDate(activity.start_date);

          const timeText = [
            activity.start_time
              ? activity.start_time.slice(0, 5)
              : "",
            activity.end_time
              ? activity.end_time.slice(0, 5)
              : ""
          ].filter(Boolean).join(" - ");

          return `
            <article class="public-activity-card">

              ${imageHTML}

              <div class="public-activity-content">

                ${activity.activity_type ? `
                  <span class="public-activity-type">
                    ${facmEscapeHTML(activity.activity_type)}
                  </span>
                ` : ""}

                <h3>${facmEscapeHTML(activity.title)}</h3>

                <div class="public-activity-details">

                  ${dateText ? `
                    <p>
                      <i class="fa-regular fa-calendar"></i>
                      ${facmEscapeHTML(dateText)}
                    </p>
                  ` : ""}

                  ${timeText ? `
                    <p>
                      <i class="fa-regular fa-clock"></i>
                      ${facmEscapeHTML(timeText)}
                    </p>
                  ` : ""}

                  ${activity.location ? `
                    <p>
                      <i class="fa-solid fa-location-dot"></i>
                      ${facmEscapeHTML(activity.location)}
                    </p>
                  ` : ""}

                </div>

                ${activity.description ? `
                  <p class="public-activity-description">
                    ${facmEscapeHTML(activity.description)}
                  </p>
                ` : ""}

              </div>

            </article>
          `;

        }).join("")}

      </div>
    `;

  } catch (error) {

    console.error("Erreur activités publiques :", error);

    container.innerHTML = `
      <div class="activities-empty">
        <h3>Impossible de charger les activités</h3>
        <p>Veuillez réessayer ultérieurement.</p>
      </div>
    `;

  }

}

/* =====================================================
   ACTUALITÉS PUBLIQUES
   ===================================================== */

async function initializePublicNews() {

  const container = document.getElementById(
    "public-news-container"
  );

  if (!container) return;

  const db = window.facmSupabase;

  if (!db) {
    container.textContent =
      "Le service des actualités est momentanément indisponible.";
    return;
  }

  try {

    const { data, error } = await db
      .from("news")
      .select(`
        id,
        title,
        category,
        excerpt,
        content,
        image_url,
        published_at,
        created_at
      `)
      .eq("status", "published")
      .order("published_at", { ascending: false });

    if (error) throw error;

    const newsItems = data || [];

    if (newsItems.length === 0) {

      container.innerHTML = `
        <div class="news-empty">

          <div class="news-empty-icon">
            <i class="fa-regular fa-newspaper"></i>
          </div>

          <h3>Nos actualités arrivent bientôt</h3>

          <p>
            Retrouvez prochainement les informations
            et annonces officielles du festival.
          </p>

        </div>
      `;

      return;
    }

    container.innerHTML = `
      <div class="public-news-grid">

        ${newsItems.map(item => {

          const imageURL = facmSafeURL(item.image_url);

          const imageHTML = imageURL ? `
            <div class="public-news-image">
              <img
                src="${facmEscapeHTML(imageURL)}"
                alt="${facmEscapeHTML(item.title)}"
                loading="lazy">
            </div>
          ` : "";

          const dateValue = item.published_at || item.created_at;

          const dateText = dateValue
            ? new Date(dateValue).toLocaleDateString("fr-FR", {
                day: "numeric",
                month: "long",
                year: "numeric"
              })
            : "";

          const description = item.excerpt || item.content || "";

          return `
            <article class="public-news-card">

              ${imageHTML}

              <div class="public-news-content">

                <span class="public-news-category">
                  ${facmEscapeHTML(item.category || "Actualité")}
                </span>

                <h3>${facmEscapeHTML(item.title)}</h3>

                ${dateText ? `
                  <p class="public-news-date">
                    <i class="fa-regular fa-calendar"></i>
                    ${facmEscapeHTML(dateText)}
                  </p>
                ` : ""}

                ${description ? `
                  <p class="public-news-description">
                    ${facmEscapeHTML(description)}
                  </p>
                ` : ""}

              </div>

            </article>
          `;

        }).join("")}

      </div>
    `;

  } catch (error) {

    console.error("Erreur actualités publiques :", error);

    container.innerHTML = `
      <div class="news-empty">
        <div class="news-empty-icon">
          <i class="fa-solid fa-triangle-exclamation"></i>
        </div>
        <h3>Impossible de charger les actualités</h3>
        <p>Veuillez réessayer ultérieurement.</p>
      </div>
    `;

  }

}


/* =====================================================
   MEMBRES DU COMITÉ PUBLIC
   ===================================================== */

async function initializePublicTeam() {

  const container = document.getElementById(
    "public-team-container"
  );

  if (!container) return;

  const db = window.facmSupabase;

  if (!db) {
    container.textContent =
      "Le service du comité est momentanément indisponible.";
    return;
  }

  try {

    const { data, error } = await db
      .from("team_members")
      .select(`
        id,
        full_name,
        position,
        biography,
        photo_url,
        organization,
        display_order
      `)
      .eq("status", "published")
      .order("display_order", { ascending: true });

    if (error) throw error;

    const members = data || [];

    if (members.length === 0) {

      container.innerHTML = `
        <div class="team-empty">
          <h3>Notre comité sera bientôt présenté</h3>
          <p>
            Les informations sur les membres de l'organisation
            seront publiées prochainement.
          </p>
        </div>
      `;

      return;
    }

    container.innerHTML = `
      <div class="public-team-grid">

        ${members.map(member => {

          let photoURL = "";

          if (member.photo_url) {

            const { data: photoData } = db.storage
              .from("team-photos")
              .getPublicUrl(member.photo_url);

            photoURL = photoData?.publicUrl || "";

          }

          const safePhotoURL = facmSafeURL(photoURL);

          const photoHTML = safePhotoURL ? `
            <div class="public-team-photo">
              <img
                src="${facmEscapeHTML(safePhotoURL)}"
                alt="${facmEscapeHTML(member.full_name)}"
                loading="lazy">
            </div>
          ` : "";

          return `
            <article class="public-team-card">

              ${photoHTML}

              <div class="public-team-content">

                <span class="public-team-organization">
                  ${facmEscapeHTML(
                    member.organization || "TEAM LEADERS"
                  )}
                </span>

                <h3>${facmEscapeHTML(member.full_name)}</h3>

                <p class="public-team-position">
                  ${facmEscapeHTML(member.position)}
                </p>

                ${member.biography ? `
                  <p class="public-team-biography">
                    ${facmEscapeHTML(member.biography)}
                  </p>
                ` : ""}

              </div>

            </article>
          `;

        }).join("")}

      </div>
    `;

  } catch (error) {

    console.error("Erreur membres du comité :", error);

    container.innerHTML = `
      <div class="team-empty">
        <h3>Impossible de charger les membres du comité</h3>
        <p>Veuillez réessayer ultérieurement.</p>
      </div>
    `;

  }

}


/* =====================================================
   SPONSORS ET PARTENAIRES PUBLICS
   ===================================================== */

async function initializePublicPartners() {

  const container = document.getElementById(
    "public-partners-container"
  );

  if (!container) return;

  const db = window.facmSupabase;

  if (!db) {
    container.textContent =
      "Le service des partenaires est momentanément indisponible.";
    return;
  }

  try {

    const { data, error } = await db
      .from("partners")
      .select(`
        id,
        name,
        description,
        logo_url,
        website_url,
        category,
        display_order,
        created_at
      `)
      .eq("status", "published")
      .order("display_order", { ascending: true })
      .order("created_at", { ascending: false });

    if (error) throw error;

    const partners = data || [];

    if (partners.length === 0) {

      container.innerHTML = `
        <div class="partners-empty">

          <i class="fa-solid fa-handshake"></i>

          <h3>Nos partenaires seront bientôt présentés</h3>

          <p>
            Retrouvez prochainement les organisations
            qui soutiennent le Festival Afro Culturel Maniema.
          </p>

        </div>
      `;

      return;
    }

    container.innerHTML = `
      <div class="public-partners-grid">

        ${partners.map(partner => {

          const websiteURL = facmSafeURL(partner.website_url);
          const logoURL = facmSafeURL(partner.logo_url);

          const categoryLabel =
            partner.category === "sponsor"
              ? "Sponsor officiel"
              : "Partenaire officiel";

          const logoHTML = logoURL ? `
            <div class="public-partner-logo">
              <img
                src="${facmEscapeHTML(logoURL)}"
                alt="Logo ${facmEscapeHTML(partner.name)}"
                loading="lazy">
            </div>
          ` : `
            <div class="public-partner-logo partners-no-logo">
              <i class="fa-solid fa-handshake"></i>
            </div>
          `;

          const nameHTML = websiteURL ? `
            <a
              href="${facmEscapeHTML(websiteURL)}"
              target="_blank"
              rel="noopener noreferrer">
              ${facmEscapeHTML(partner.name)}
            </a>
          ` : facmEscapeHTML(partner.name);

          return `
            <article class="public-partner-card">

              ${websiteURL ? `
                <a
                  class="public-partner-logo-link"
                  href="${facmEscapeHTML(websiteURL)}"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Visiter le site de ${facmEscapeHTML(partner.name)}">
                  ${logoHTML}
                </a>
              ` : logoHTML}

              <div class="public-partner-content">

                <span class="public-partner-category">
                  ${categoryLabel}
                </span>

                <h3>${nameHTML}</h3>

                ${partner.description ? `
                  <p>
                    ${facmEscapeHTML(partner.description)}
                  </p>
                ` : ""}

              </div>

            </article>
          `;

        }).join("")}

      </div>
    `;

  } catch (error) {

    console.error("Erreur sponsors et partenaires :", error);

    container.innerHTML = `
      <div class="partners-empty">
        <h3>Impossible de charger les partenaires</h3>
        <p>Veuillez réessayer ultérieurement.</p>
      </div>
    `;

  }

}

/* =====================================================
   GALERIE PUBLIQUE
   ===================================================== */

async function initializePublicMedia() {

  const container = document.getElementById(
    "public-media-container"
  );

  if (!container) return;

  const db = window.facmSupabase;

  if (!db) {
    container.textContent =
      "Le service de la galerie est momentanément indisponible.";
    return;
  }

  try {

    const { data, error } = await db
      .from("media")
      .select(`
        id,
        title,
        description,
        media_type,
        file_url,
        category,
        display_order,
        created_at
      `)
      .eq("status", "published")
      .order("display_order", { ascending: true })
      .order("created_at", { ascending: false });

    if (error) throw error;

    const mediaItems = (data || []).filter(item =>
      ["image", "video"].includes(item.media_type) &&
      facmSafeURL(item.file_url)
    );

    if (mediaItems.length === 0) {

      container.innerHTML = `
        <div class="gallery-empty">

          <div class="gallery-empty-icon">
            <i class="fa-regular fa-images"></i>
          </div>

          <h3>Notre galerie sera bientôt disponible</h3>

          <p>
            Retrouvez prochainement les photos et vidéos
            du Festival Afro Culturel Maniema.
          </p>

        </div>
      `;

      return;
    }

    /* ==============================================
       CONSTRUCTION DES CARTES DE LA GALERIE
    ============================================== */

    container.innerHTML = `
      <div class="public-media-grid">

        ${mediaItems.map(item => {

          const mediaURL = facmSafeURL(item.file_url);
          const title = facmEscapeHTML(item.title);
          const description = facmEscapeHTML(item.description);
          const category = facmEscapeHTML(
            item.category || "Festival"
          );

          let mediaContent = "";

          if (item.media_type === "image") {

            mediaContent = `
              <img
                class="gallery-lightbox-trigger"
                src="${facmEscapeHTML(mediaURL)}"
                alt="${title}"
                data-media-id="${facmEscapeHTML(item.id)}"
                loading="lazy"
                role="button"
                tabindex="0"
                aria-label="Agrandir : ${title}">
            `;

          } else {

            const videoMimeType =
              /\.webm(?:[?#]|$)/i.test(mediaURL)
                ? "video/webm"
                : "video/mp4";

            mediaContent = `
              <video
                class="gallery-video-player"
                controls
                preload="metadata"
                playsinline
                aria-label="${title}">

                <source
                  src="${facmEscapeHTML(mediaURL)}"
                  type="${videoMimeType}">

                Votre navigateur ne prend pas en charge
                la lecture vidéo.

              </video>

              <button
                type="button"
                class="gallery-video-open"
                data-media-id="${facmEscapeHTML(item.id)}"
                aria-label="Agrandir la vidéo : ${title}">

                <i class="fa-solid fa-expand"></i>
                Agrandir la vidéo

              </button>
            `;

          }

          return `
            <article class="public-media-card">

              <div class="public-media-visual">

                ${mediaContent}

                <span class="public-media-type">
                  ${item.media_type === "video" ? "VIDÉO" : "PHOTO"}
                </span>

              </div>

              <div class="public-media-content">

                <span class="public-media-category">
                  ${category}
                </span>

                <h3>${title}</h3>

                ${description ? `
                  <p>${description}</p>
                ` : ""}

              </div>

            </article>
          `;

        }).join("")}

      </div>
    `;


    /* ==============================================
       PRÉPARATION DES MÉDIAS POUR LA LIGHTBOX
    ============================================== */

    const galleryItems = mediaItems.map(item => {

      const url = facmSafeURL(item.file_url);

      return {
        id: String(item.id),
        url: url,
        title: String(item.title || ""),
        type: item.media_type,
        mimeType: /\.webm(?:[?#]|$)/i.test(url)
          ? "video/webm"
          : "video/mp4"
      };

    });


    /* ==============================================
       CRÉATION DE LA LIGHTBOX
    ============================================== */

    const lightbox = document.createElement("div");

    lightbox.className = "gallery-lightbox";
    lightbox.hidden = true;

    lightbox.setAttribute("role", "dialog");
    lightbox.setAttribute("aria-modal", "true");
    lightbox.setAttribute(
      "aria-label",
      "Visionneuse de la galerie"
    );

    lightbox.innerHTML = `

      <button
        type="button"
        class="lightbox-close"
        aria-label="Fermer">

        &times;

      </button>

      <button
        type="button"
        class="lightbox-prev"
        aria-label="Média précédent">

        &#10094;

      </button>

      <div class="lightbox-content">

        <img
          class="lightbox-image"
          src=""
          alt=""
          hidden>

        <video
          class="lightbox-video"
          controls
          playsinline
          preload="metadata"
          hidden>
        </video>

        <p class="lightbox-caption"></p>

      </div>

      <button
        type="button"
        class="lightbox-next"
        aria-label="Média suivant">

        &#10095;

      </button>

    `;

    container.appendChild(lightbox);


    /* ==============================================
       ÉLÉMENTS DE LA LIGHTBOX
    ============================================== */

    const lightboxImage =
      lightbox.querySelector(".lightbox-image");

    const lightboxVideo =
      lightbox.querySelector(".lightbox-video");

    const lightboxCaption =
      lightbox.querySelector(".lightbox-caption");

    const closeButton =
      lightbox.querySelector(".lightbox-close");

    const prevButton =
      lightbox.querySelector(".lightbox-prev");

    const nextButton =
      lightbox.querySelector(".lightbox-next");

    let currentImageIndex = 0;
    let activeTrigger = null;


    /* ==============================================
       ARRÊTER ET RÉINITIALISER LA VIDÉO
    ============================================== */

    function resetLightboxVideo() {

      lightboxVideo.pause();

      lightboxVideo.removeAttribute("src");

      lightboxVideo.innerHTML = "";

      lightboxVideo.load();

      lightboxVideo.hidden = true;

    }


    /* ==============================================
       AFFICHER UNE PHOTO OU UNE VIDÉO
    ============================================== */

    function showLightboxImage(index) {

      currentImageIndex =
        (index + galleryItems.length) % galleryItems.length;

      const item = galleryItems[currentImageIndex];

      resetLightboxVideo();

      lightboxImage.hidden = true;
      lightboxImage.removeAttribute("src");
      lightboxImage.alt = "";

      if (item.type === "image") {

        lightboxImage.src = item.url;
        lightboxImage.alt = item.title;
        lightboxImage.hidden = false;

      } else {

        lightboxVideo.innerHTML = "";

        const source = document.createElement("source");

        source.src = item.url;
        source.type = item.mimeType;

        lightboxVideo.appendChild(source);

        lightboxVideo.hidden = false;
        lightboxVideo.load();

      }

      lightboxCaption.textContent =
        item.title +
        " — " +
        (currentImageIndex + 1) +
        " / " +
        galleryItems.length;

      prevButton.hidden = galleryItems.length <= 1;
      nextButton.hidden = galleryItems.length <= 1;

    }


    /* ==============================================
       OUVRIR LA LIGHTBOX
    ============================================== */

    function openLightbox(index, trigger) {

      activeTrigger = trigger;

      showLightboxImage(index);

      lightbox.hidden = false;

      document.body.classList.add("lightbox-open");

      closeButton.focus();

    }


    /* ==============================================
       FERMER LA LIGHTBOX
    ============================================== */

    function closeLightbox() {

      lightbox.hidden = true;

      resetLightboxVideo();

      lightboxImage.removeAttribute("src");
      lightboxImage.hidden = true;

      document.body.classList.remove("lightbox-open");

      if (activeTrigger && activeTrigger.isConnected) {
        activeTrigger.focus();
      }

      activeTrigger = null;

    }


    /* ==============================================
       NAVIGATION ENTRE LES MÉDIAS
    ============================================== */

    function previousImage() {

      if (galleryItems.length <= 1) return;

      showLightboxImage(currentImageIndex - 1);

    }

    function nextImage() {

      if (galleryItems.length <= 1) return;

      showLightboxImage(currentImageIndex + 1);

    }


    /* ==============================================
       OUVERTURE DES PHOTOS
    ============================================== */

    container.querySelectorAll(
      ".gallery-lightbox-trigger"
    ).forEach(trigger => {

      const index = galleryItems.findIndex(
        item => item.id === trigger.dataset.mediaId
      );

      if (index === -1) return;

      trigger.addEventListener("click", event => {

        event.preventDefault();

        openLightbox(index, trigger);

      });

      trigger.addEventListener("keydown", event => {

        if (
          event.key === "Enter" ||
          event.key === " "
        ) {

          event.preventDefault();

          openLightbox(index, trigger);

        }

      });

    });


    /* ==============================================
       OUVERTURE DES VIDÉOS
    ============================================== */

    container.querySelectorAll(
      ".gallery-video-open"
    ).forEach(trigger => {

      const index = galleryItems.findIndex(
        item => item.id === trigger.dataset.mediaId
      );

      if (index === -1) return;

      trigger.addEventListener("click", () => {

        openLightbox(index, trigger);

      });

    });


    /* ==============================================
       ÉVÉNEMENTS DE LA LIGHTBOX
    ============================================== */

    closeButton.addEventListener(
      "click",
      closeLightbox
    );

    prevButton.addEventListener(
      "click",
      previousImage
    );

    nextButton.addEventListener(
      "click",
      nextImage
    );

    lightbox.addEventListener("click", event => {

      if (event.target === lightbox) {
        closeLightbox();
      }

    });

    lightbox.addEventListener("keydown", event => {

      if (event.key === "Escape") {

        event.preventDefault();
        closeLightbox();

      }

      if (event.key === "ArrowLeft") {

        event.preventDefault();
        previousImage();

      }

      if (event.key === "ArrowRight") {

        event.preventDefault();
        nextImage();

      }

    });

    console.log(
      "FACM : galerie publique chargée.",
      galleryItems.length,
      "média(s)."
    );

  } catch (error) {

    console.error("Erreur galerie publique :", error);

    container.innerHTML = `
      <div class="gallery-empty">

        <div class="gallery-empty-icon">
          <i class="fa-solid fa-triangle-exclamation"></i>
        </div>

        <h3>Impossible de charger la galerie</h3>

        <p>
          Veuillez réessayer ultérieurement.
        </p>

      </div>
    `;

  }

}
