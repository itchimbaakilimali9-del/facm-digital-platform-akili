
(() => {
  const VAPID_PUBLIC_KEY = "BOFgGX0rG00XtkicOx4V1vWRFywXZV7Kpa6gUz62rk8UHQwXeUNzPMsQd3lokSGdM4hi146MIDuOKI9FPVBREEQ";

  const toUint8Array = (base64) => {
    const padding = "=".repeat((4 - base64.length % 4) % 4);
    const raw = atob(
      (base64 + padding)
        .replace(/-/g, "+")
        .replace(/_/g, "/")
    );

    return Uint8Array.from(
      [...raw].map((c) => c.charCodeAt(0))
    );
  };

  window.facmEnablePushNotifications = async function () {
    try {
      if (!window.facmSupabase) {
        throw new Error("Client Supabase indisponible.");
      }

      if (
        !("serviceWorker" in navigator) ||
        !("PushManager" in window)
      ) {
        throw new Error(
          "Ce navigateur ne prend pas en charge les notifications Push."
        );
      }

      if (VAPID_PUBLIC_KEY.startsWith("REMPLACER")) {
        throw new Error("La clé publique VAPID n'est pas configurée.");
      }

      const permission = await Notification.requestPermission();

      if (permission !== "granted") {
        throw new Error("Autorisation de notification refusée.");
      }

      const registration = await navigator.serviceWorker.register("/sw.js", {
        scope: "/"
      });

      let subscription = await registration.pushManager.getSubscription();

      if (!subscription) {
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: toUint8Array(VAPID_PUBLIC_KEY)
        });
      }

      const { data: authData, error: authError } =
        await window.facmSupabase.auth.getUser();

      if (authError || !authData.user) {
        throw new Error(
          "Connectez-vous à votre compte administrateur."
        );
      }

      const json = subscription.toJSON();

      const { error } = await window.facmSupabase
        .from("admin_push_subscriptions")
        .upsert({
          user_id: authData.user.id,
          endpoint: json.endpoint,
          subscription: json,
          updated_at: new Date().toISOString()
        }, {
          onConflict: "endpoint"
        });

      if (error) throw error;

      window.showFacmUltraToast?.(
        "Notifications Push activées sur cet appareil."
      );

      if (!window.showFacmUltraToast) {
        alert("Notifications Push activées sur cet appareil.");
      }

    } catch (error) {
      console.error("Activation Push FACM :", error);

      const message = error?.message ||
        "Impossible d'activer les notifications.";

      window.showFacmUltraToast?.(message, {
        type: "error"
      });

      if (!window.showFacmUltraToast) {
        alert(message);
      }
    }
  };
})();
 