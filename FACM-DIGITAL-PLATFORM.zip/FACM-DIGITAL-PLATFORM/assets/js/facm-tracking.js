(() => {
  if (!window.facmSupabase || !window.crypto?.randomUUID) return;
  const client = window.facmSupabase;
  const UUID_KEY = "facm_visitor_id_v1";
  const SESSION_KEY = "facm_session_id_v1";
  const getId = (storage, key) => {
    let value = storage.getItem(key);
    if (!value) { value = crypto.randomUUID(); storage.setItem(key, value); }
    return value;
  };
  let visitorId, sessionId;
  try {
    visitorId = getId(localStorage, UUID_KEY);
    sessionId = getId(sessionStorage, SESSION_KEY);
  } catch (_) { return; }
  const pagePath = `${location.pathname}${location.hash || ""}`.slice(0, 300);
  const send = async (pageView = false) => {
    try {
      await client.functions.invoke("site-analytics", {
        body: { action: "track", visitor_id: visitorId, session_id: sessionId, page_path: pagePath, page_view: pageView }
      });
    } catch (e) { console.debug("FACM analytics indisponible", e); }
  };
  send(true);
  const heartbeat = window.setInterval(() => {
    if (document.visibilityState === "visible") send(false);
  }, 30000);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") send(false);
  });
  window.addEventListener("pagehide", () => window.clearInterval(heartbeat), { once: true });
})();
