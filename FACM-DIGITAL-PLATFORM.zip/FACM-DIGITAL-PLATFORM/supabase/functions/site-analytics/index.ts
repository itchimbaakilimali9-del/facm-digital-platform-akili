import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, apikey, x-client-info, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const reply = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { ...cors, "Content-Type": "application/json" } });
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return reply({ error: "Méthode non autorisée." }, 405);
  try {
    const body = await req.json();
    const db = createClient(URL, SERVICE, { auth: { persistSession: false } });
    if (body.action === "track") {
      const visitor_id = String(body.visitor_id || "");
      const session_id = String(body.session_id || "");
      const page_path = String(body.page_path || "/").slice(0, 300);
      if (!/^[0-9a-f-]{36}$/i.test(visitor_id) || !/^[0-9a-f-]{36}$/i.test(session_id)) return reply({ error: "Identifiants de visite invalides." }, 400);
      const now = new Date().toISOString();
      const { error: visitorError } = await db.from("site_visitors").upsert({ visitor_id, last_seen: now }, { onConflict: "visitor_id" });
      if (visitorError) throw visitorError;
      const { error: sessionError } = await db.from("visitor_sessions").upsert({ session_id, visitor_id, page_path, last_seen: now }, { onConflict: "session_id" });
      if (sessionError) throw sessionError;
      if (body.page_view === true) {
        const { error: viewError } = await db.from("site_page_views").insert({ visitor_id, session_id, page_path });
        if (viewError) throw viewError;
      }
      return reply({ success: true });
    }
    if (body.action === "stats") {
      const authorization = req.headers.get("Authorization");
      if (!authorization) return reply({ error: "Authentification requise." }, 401);
      const userClient = createClient(URL, ANON, { global: { headers: { Authorization: authorization } }, auth: { persistSession: false } });
      const token = authorization.replace(/^Bearer\s+/i, "");
      const { data: authData, error: authError } = await userClient.auth.getUser(token);
      if (authError || !authData.user) return reply({ error: "Session invalide." }, 401);
      const { data: profile, error: profileError } = await db.from("profiles").select("role, active").eq("id", authData.user.id).maybeSingle();
      if (profileError || !profile || profile.role !== "admin" || profile.active !== true) return reply({ error: "Accès administrateur requis." }, 403);
      const now = new Date();
      const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
      const onlineSince = new Date(Date.now() - 90_000).toISOString();
      const [visitors, online, views, todayViews] = await Promise.all([
        db.from("site_visitors").select("visitor_id", { count: "exact", head: true }),
        db.from("visitor_sessions").select("session_id", { count: "exact", head: true }).gte("last_seen", onlineSince),
        db.from("site_page_views").select("id", { count: "exact", head: true }),
        db.from("site_page_views").select("id", { count: "exact", head: true }).gte("viewed_at", dayStart),
      ]);
      for (const r of [visitors, online, views, todayViews]) if (r.error) throw r.error;
      return reply({ total_visitors: visitors.count || 0, online_visitors: online.count || 0, total_page_views: views.count || 0, page_views_today: todayViews.count || 0, online_window_seconds: 90 });
    }
    return reply({ error: "Action inconnue." }, 400);
  } catch (e) { console.error(e); return reply({ error: e instanceof Error ? e.message : "Erreur serveur." }, 500); }
});
