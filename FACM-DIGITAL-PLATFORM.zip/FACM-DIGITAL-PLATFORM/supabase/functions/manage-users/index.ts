import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const PRINCIPAL_EMAIL = "itchimbaakilimali9@gmail.com";
const ALLOWED_ROLES = ["admin", "candidate", "team"] as const;
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, "Content-Type": "application/json" },
});
const clean = (v: unknown, max = 200) => String(v ?? "").trim().slice(0, max);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Méthode non autorisée." }, 405);

  try {
    if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !SERVICE_ROLE_KEY) {
      throw new Error("Configuration serveur Supabase incomplète.");
    }
    const authorization = req.headers.get("Authorization");
    if (!authorization) return json({ error: "Authentification requise." }, 401);

    const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authorization } },
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const token = authorization.replace(/^Bearer\s+/i, "");
    const { data: authData, error: authError } = await userClient.auth.getUser(token);
    if (authError || !authData.user) return json({ error: "Session invalide ou expirée." }, 401);

    const adminClient = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const caller = authData.user;
    const callerEmail = (caller.email || "").trim().toLowerCase();
    const { data: callerProfile, error: callerProfileError } = await adminClient
      .from("profiles").select("id, role, active").eq("id", caller.id).maybeSingle();
    if (callerProfileError || !callerProfile || callerProfile.role !== "admin" || callerProfile.active !== true) {
      return json({ error: "Accès réservé aux administrateurs actifs." }, 403);
    }

    const body = await req.json().catch(() => ({}));
    const action = clean(body.action, 30);
    const isPrincipal = callerEmail === PRINCIPAL_EMAIL;

    // La consultation est permise à tout administrateur actif.
    if (action === "list") {
      const authUsers: any[] = [];
      let page = 1;
      const perPage = 1000;
      while (true) {
        const { data, error } = await adminClient.auth.admin.listUsers({ page, perPage });
        if (error) throw error;
        authUsers.push(...data.users);
        if (data.users.length < perPage) break;
        page++;
      }
      const { data: profiles, error: profilesError } = await adminClient
        .from("profiles").select("id, full_name, phone, role, active, created_at");
      if (profilesError) throw profilesError;
      const byId = new Map((profiles || []).map((p: any) => [p.id, p]));
      const users = authUsers.map((u: any) => {
        const p: any = byId.get(u.id) || {};
        return {
          id: u.id,
          email: u.email || "",
          full_name: p.full_name || u.user_metadata?.full_name || "Utilisateur",
          phone: p.phone || u.user_metadata?.phone || "",
          role: p.role || u.user_metadata?.role || "candidate",
          active: p.active === true && !u.banned_until,
          created_at: p.created_at || u.created_at,
          is_principal: (u.email || "").toLowerCase() === PRINCIPAL_EMAIL,
        };
      });
      return json({ users, total: users.length, caller_is_principal: isPrincipal });
    }

    // Toutes les opérations de mutation sont exclusivement réservées au principal.
    if (!isPrincipal) return json({ error: "Seul l'administrateur principal peut gérer les comptes." }, 403);

    if (action === "create") {
      const full_name = clean(body.full_name, 160);
      const email = clean(body.email, 254).toLowerCase();
      const phone = clean(body.phone, 40);
      const password = String(body.password || "");
      const role = clean(body.role, 20);
      if (!full_name || !email || !/^\S+@\S+\.\S+$/.test(email)) return json({ error: "Nom complet et adresse e-mail valides obligatoires." }, 400);
      if (password.length < 8) return json({ error: "Le mot de passe doit contenir au moins 8 caractères." }, 400);
      if (!(ALLOWED_ROLES as readonly string[]).includes(role)) return json({ error: "Rôle non autorisé." }, 400);

      const { data: created, error: createError } = await adminClient.auth.admin.createUser({
        email, password, email_confirm: true,
        user_metadata: { full_name, phone, role },
      });
      if (createError) throw createError;
      if (!created.user) throw new Error("Supabase n'a pas retourné le nouvel utilisateur.");

      const { error: profileInsertError } = await adminClient.from("profiles").insert({
        id: created.user.id, full_name, email, phone, role, active: true,
      });
      if (profileInsertError) {
        await adminClient.auth.admin.deleteUser(created.user.id);
        throw new Error(`Compte Auth créé mais profil non enregistré. Création annulée : ${profileInsertError.message}`);
      }
      return json({ success: true, user_id: created.user.id, message: "Compte et profil créés." });
    }

    if (action === "update") {
      const userId = clean(body.user_id, 80);
      const full_name = clean(body.full_name, 160);
      const phone = clean(body.phone, 40);
      const role = clean(body.role, 20);
      if (!userId || !full_name) return json({ error: "Identifiant et nom complet obligatoires." }, 400);
      if (!(ALLOWED_ROLES as readonly string[]).includes(role)) return json({ error: "Rôle non autorisé." }, 400);
      const { data: target, error: targetError } = await adminClient.auth.admin.getUserById(userId);
      if (targetError || !target.user) return json({ error: "Utilisateur introuvable." }, 404);
      if ((target.user.email || "").toLowerCase() === PRINCIPAL_EMAIL) return json({ error: "Le compte principal est protégé." }, 403);
      const { error: profileUpdateError } = await adminClient.from("profiles").upsert({
        id: userId, full_name, phone, role,
      }, { onConflict: "id" });
      if (profileUpdateError) throw profileUpdateError;
      const { error: authUpdateError } = await adminClient.auth.admin.updateUserById(userId, {
        user_metadata: { ...(target.user.user_metadata || {}), full_name, phone, role },
      });
      if (authUpdateError) throw authUpdateError;
      return json({ success: true, message: "Utilisateur modifié." });
    }

    if (action === "status") {
      const userId = clean(body.user_id, 80);
      const active = body.active === true;
      if (!userId) return json({ error: "Identifiant utilisateur manquant." }, 400);
      const { data: target, error: targetError } = await adminClient.auth.admin.getUserById(userId);
      if (targetError || !target.user) return json({ error: "Utilisateur introuvable." }, 404);
      if ((target.user.email || "").toLowerCase() === PRINCIPAL_EMAIL) return json({ error: "Le compte principal ne peut pas être désactivé." }, 403);
      const { error: profileError } = await adminClient.from("profiles").update({ active }).eq("id", userId);
      if (profileError) throw profileError;
      const { error: authUpdateError } = await adminClient.auth.admin.updateUserById(userId, {
        ban_duration: active ? "none" : "876000h",
      });
      if (authUpdateError) {
        await adminClient.from("profiles").update({ active: !active }).eq("id", userId);
        throw authUpdateError;
      }
      return json({ success: true, active, message: active ? "Compte activé." : "Compte désactivé." });
    }

    if (action === "delete") {
      const userId = clean(body.user_id, 80);
      if (!userId) return json({ error: "Identifiant utilisateur manquant." }, 400);
      if (userId === caller.id) return json({ error: "Vous ne pouvez pas supprimer votre propre compte pendant votre session." }, 403);
      const { data: target, error: targetError } = await adminClient.auth.admin.getUserById(userId);
      if (targetError || !target.user) return json({ error: "Utilisateur introuvable." }, 404);
      if ((target.user.email || "").toLowerCase() === PRINCIPAL_EMAIL) return json({ error: "Le compte administrateur principal est protégé." }, 403);

      // Nettoyage des pièces jointes et candidatures appartenant à ce compte.
      const { data: applications, error: applicationsReadError } = await adminClient
        .from("applications").select("id").eq("user_id", userId);
      if (applicationsReadError) throw applicationsReadError;
      const applicationIds = (applications || []).map((a: any) => a.id);
      if (applicationIds.length) {
        const { data: docs, error: docsReadError } = await adminClient
          .from("application_documents").select("storage_path").in("application_id", applicationIds);
        if (docsReadError) throw docsReadError;
        const paths = (docs || []).map((d: any) => d.storage_path).filter(Boolean);
        if (paths.length) {
          const { error: storageError } = await adminClient.storage.from("candidate-documents").remove(paths);
          if (storageError) throw new Error(`Impossible de supprimer les documents du candidat : ${storageError.message}`);
        }
        const { error: docsDeleteError } = await adminClient.from("application_documents").delete().in("application_id", applicationIds);
        if (docsDeleteError) throw docsDeleteError;
        const { error: appsDeleteError } = await adminClient.from("applications").delete().eq("user_id", userId);
        if (appsDeleteError) throw appsDeleteError;
      }
      // Suppression des notifications et abonnements Push associés, puis profil et compte Auth.
      await adminClient.from("notifications").delete().eq("user_id", userId);
      await adminClient.from("admin_push_subscriptions").delete().eq("user_id", userId);
      const { error: profileDeleteError } = await adminClient.from("profiles").delete().eq("id", userId);
      if (profileDeleteError) throw profileDeleteError;
      const { error: authDeleteError } = await adminClient.auth.admin.deleteUser(userId);
      if (authDeleteError) throw authDeleteError;
      return json({ success: true, message: "Compte, profil, candidatures et documents associés supprimés." });
    }

    return json({ error: "Action inconnue. Actions autorisées : list, create, update, status, delete." }, 400);
  } catch (error) {
    console.error("manage-users error:", error);
    return json({ error: error instanceof Error ? error.message : "Erreur serveur inattendue." }, 500);
  }
});
