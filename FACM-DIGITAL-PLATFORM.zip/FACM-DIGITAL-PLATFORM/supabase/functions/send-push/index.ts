import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";
const URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const WEBHOOK_SECRET = Deno.env.get("FACM_WEBHOOK_SECRET")!;
const PUBLIC_KEY = Deno.env.get("VAPID_PUBLIC_KEY")!;
const PRIVATE_KEY = Deno.env.get("VAPID_PRIVATE_KEY")!;
const SUBJECT = Deno.env.get("VAPID_SUBJECT") || "mailto:itchimbaakilimali9@gmail.com";
Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  if (!WEBHOOK_SECRET || req.headers.get("x-facm-webhook-secret") !== WEBHOOK_SECRET) return new Response("Unauthorized", { status: 401 });
  try {
    webpush.setVapidDetails(SUBJECT, PUBLIC_KEY, PRIVATE_KEY);
    const payload = await req.json();
    const record = payload.record || {};
    const table = payload.table || "";
    const db = createClient(URL, SERVICE, { auth: { persistSession: false } });
    let title = "FACM DIGITAL PLATFORM";
    let message = "Une nouvelle activité est enregistrée.";
    let type = "info";
    let relatedId: string | null = null;

    if (table === "applications") {
      title = "Nouvelle candidature reçue";
      message = `${record.full_name || "Un candidat"} vient d'enregistrer une candidature${record.category ? ` (${record.category})` : ""}.`;
      type = "success";
      relatedId = record.id || null;
    } else if (table === "site_page_views") {
      const sessionId = String(record.session_id || "");
      if (!sessionId) return new Response("No session", { status: 200 });
      const { data: claimed, error: claimError } = await db.from("visitor_push_alerts").upsert({ session_id: sessionId }, { onConflict: "session_id", ignoreDuplicates: true }).select("session_id");
      if (claimError) throw claimError;
      if (!claimed?.length) return new Response("Already notified", { status: 200 });
      title = "Nouveau visiteur sur le site";
      message = `Un visiteur consulte actuellement la page ${String(record.page_path || "/").slice(0, 120)}.`;
      type = "info";
    } else return new Response("Ignored table", { status: 200 });

    const { data: admins, error: adminsError } = await db.from("profiles").select("id").eq("role", "admin").eq("active", true);
    if (adminsError) throw adminsError;
    const ids = (admins || []).map((a: any) => a.id);
    if (!ids.length) return new Response("No active admins", { status: 200 });
    const notificationRows = ids.map((id: string) => ({ user_id: id, title, message, type, is_read: false, related_id: relatedId }));
    const { error: insertError } = await db.from("notifications").insert(notificationRows);
    if (insertError) console.error("Notification centre insert:", insertError.message);
    const { data: subscriptions, error: subError } = await db.from("admin_push_subscriptions").select("id, user_id, subscription").in("user_id", ids);
    if (subError) throw subError;
    const pushPayload = JSON.stringify({ title, body: message, icon: "/assets/icons/icon-192.png", badge: "/assets/icons/icon-192.png", url: table === "applications" ? "/admin/dashboard.html" : "/" });
    const results = await Promise.allSettled((subscriptions || []).map(async (row: any) => {
      try { await webpush.sendNotification(row.subscription, pushPayload); }
      catch (e: any) {
        if (e?.statusCode === 404 || e?.statusCode === 410) await db.from("admin_push_subscriptions").delete().eq("id", row.id);
        else console.error("Push error:", e?.message || e);
      }
    }));
    return Response.json({ success: true, notified_admins: ids.length, push_subscriptions: subscriptions?.length || 0, settled: results.length });
  } catch (e) { console.error("send-push:", e); return Response.json({ error: e instanceof Error ? e.message : "Push error" }, { status: 500 }); }
});
