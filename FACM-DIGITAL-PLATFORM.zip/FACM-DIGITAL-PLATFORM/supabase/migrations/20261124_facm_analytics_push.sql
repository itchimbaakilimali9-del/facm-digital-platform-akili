-- FACM DIGITAL PLATFORM : analytics visiteurs et abonnements Web Push
create table if not exists public.site_visitors (
  visitor_id uuid primary key,
  first_seen timestamptz not null default now(),
  last_seen timestamptz not null default now()
);
create table if not exists public.visitor_sessions (
  session_id uuid primary key,
  visitor_id uuid not null references public.site_visitors(visitor_id) on delete cascade,
  page_path text not null default '/',
  started_at timestamptz not null default now(),
  last_seen timestamptz not null default now()
);
create index if not exists visitor_sessions_last_seen_idx on public.visitor_sessions(last_seen desc);
create table if not exists public.site_page_views (
  id bigint generated always as identity primary key,
  visitor_id uuid not null references public.site_visitors(visitor_id) on delete cascade,
  session_id uuid not null references public.visitor_sessions(session_id) on delete cascade,
  page_path text not null default '/',
  viewed_at timestamptz not null default now()
);
create index if not exists site_page_views_viewed_at_idx on public.site_page_views(viewed_at desc);

create table if not exists public.admin_push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null unique,
  subscription jsonb not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists admin_push_subscriptions_user_idx on public.admin_push_subscriptions(user_id);

create table if not exists public.visitor_push_alerts (
  session_id uuid primary key,
  sent_at timestamptz not null default now()
);

alter table public.site_visitors enable row level security;
alter table public.visitor_sessions enable row level security;
alter table public.site_page_views enable row level security;
alter table public.admin_push_subscriptions enable row level security;
alter table public.visitor_push_alerts enable row level security;

-- Les tables analytiques ne sont accessibles qu'aux fonctions Edge avec service_role.
-- Les abonnements Push sont limités au propriétaire de la session.
drop policy if exists "push subscription owner read" on public.admin_push_subscriptions;
create policy "push subscription owner read" on public.admin_push_subscriptions for select to authenticated using (auth.uid() = user_id and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin' and p.active = true));
drop policy if exists "push subscription owner insert" on public.admin_push_subscriptions;
create policy "push subscription owner insert" on public.admin_push_subscriptions for insert to authenticated with check (auth.uid() = user_id and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin' and p.active = true));
drop policy if exists "push subscription owner update" on public.admin_push_subscriptions;
create policy "push subscription owner update" on public.admin_push_subscriptions for update to authenticated using (auth.uid() = user_id and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin' and p.active = true)) with check (auth.uid() = user_id and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin' and p.active = true));
drop policy if exists "push subscription owner delete" on public.admin_push_subscriptions;
create policy "push subscription owner delete" on public.admin_push_subscriptions for delete to authenticated using (auth.uid() = user_id and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin' and p.active = true));

-- Nettoyage des sessions inactives : à exécuter périodiquement avec Supabase Cron si disponible.
-- delete from public.visitor_sessions where last_seen < now() - interval '30 days';
