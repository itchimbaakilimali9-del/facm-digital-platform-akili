const CACHE_NAME = "facm-platform-v2";
const APP_SHELL = ["/", "/index.html", "/manifest.json"];
self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then(async (cache) => {
    for (const file of APP_SHELL) { try { await cache.add(file); } catch (e) { console.warn("Cache ignoré:", file, e); } }
    await self.skipWaiting();
  }));
});
self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || request.mode !== "navigate") return;
  event.respondWith(fetch(request).catch(async () => (await caches.match(request)) || (await caches.match("/index.html")) || Response.error()));
});
self.addEventListener("push", (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (_) { data = { body: event.data?.text() || "Nouvelle activité FACM." }; }
  const title = data.title || "FACM DIGITAL PLATFORM";
  const options = {
    body: data.body || "Une nouvelle activité a été enregistrée.",
    icon: data.icon || "/assets/icons/icon-192.png",
    badge: data.badge || "/assets/icons/icon-192.png",
    data: { url: data.url || "/admin/dashboard.html" },
    vibrate: [150, 80, 150],
    tag: data.tag || "facm-notification",
    renotify: true
  };
  event.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = new URL(event.notification.data?.url || "/admin/dashboard.html", self.location.origin).href;
  event.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clients) => {
    for (const client of clients) if (client.url === target && "focus" in client) return client.focus();
    return self.clients.openWindow ? self.clients.openWindow(target) : undefined;
  }));
});
